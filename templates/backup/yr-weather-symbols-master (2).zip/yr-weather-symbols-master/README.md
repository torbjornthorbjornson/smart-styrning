Weather symbols for the new [yr.no](https://www.yr.no/en)

See [this page](https://nrkno.github.io/yr-weather-symbols/) for more details.
